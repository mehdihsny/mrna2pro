def findorfs(seq):
    frame1=[seq[i:i+3] for i in range(0, len(seq), 3)]
    frame2=[seq[i:i+3] for i in range(1,len(seq) , 3)]
    frame3=[seq[i:i+3] for i in range(2,len(seq) , 3)]
    try:
        frame1s=frame1[frame1.index("ATG"):]
    except:
        frame1se=[]
    else:
        for code in range(len(frame1s)):
            if frame1s[code]=="TAA" or frame1s[code]=="TAG" or frame1s[code]=="TGA" :
                frame1se=frame1s[:code]
                break
            else:
                pass
        try:  #if there is no stop codon.
            frame1se
        except:
            frame1se=["ATG"]
    try:
        frame2s=frame2[frame2.index("ATG"):]
    except:
        frame2se=[]
    else:
        for code in range(len(frame2s)):
            if frame2s[code]=="TAA" or frame2s[code]=="TAG" or frame2s[code]=="TGA" :
                frame2se=frame2s[:code]
                break
            else:
                pass
        try:
            frame2se
        except:
            frame2se=["ATG"]
    try:
        frame3s=frame3[frame3.index("ATG"):]
    except:
        frame3se=[]
    else:
        for code in range(len(frame3s)):
            if frame3s[code]=="TAA" or frame3s[code]=="TAG" or frame3s[code]=="TGA" :
                frame3se=frame3s[:code]
                break
            else:
                pass
        try:
            frame3se
        except:
            frame3se=["ATG"]
    return sorted([[len(frame1se),frame1se],[len(frame2se),frame2se],[len(frame3se),frame3se]],reverse=True)


def rna2pro(codonslist):
    aminoacidlist=[]
    codmean={'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L', 'CTT': 'L', 'CTC': 'L', 'CTA': 'L', 'CTG': 'L', 'ATT': 'I',
             'ATC': 'I', 'ATA': 'I', 'ATG': 'M', 'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V', 'TCT': 'S', 'TCC': 'S',
             'TCA': 'S', 'TCG': 'S', 'CCT': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P', 'ACT': 'T', 'ACC': 'T', 'ACA': 'T',
             'ACG': 'T', 'GCT': 'A', 'GCC': 'A', 'GCA': 'A', 'GCG': 'A', 'TAT': 'Y', 'TAC': 'Y', 'CAT': 'H', 'CAC': 'H',
             'CAA': 'Q', 'CAG': 'Q', 'AAT': 'N', 'AAC': 'N', 'AAA': 'K', 'AAG': 'K', 'GAT': 'D', 'GAC': 'D', 'GAA': 'E',
             'GAG': 'E', 'TGT': 'C', 'TGC': 'C', 'TGG': 'W', 'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R', 'AGT': 'S',
             'AGC': 'S', 'AGA': 'R', 'AGG': 'R', 'GGT': 'G', 'GGC': 'G', 'GGA': 'G', 'GGG': 'G'}
    for codon in codonslist:
        aminoacidlist.append(codmean[codon])
    return aminoacidlist
