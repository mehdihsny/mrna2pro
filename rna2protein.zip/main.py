from orf import findorfs
from orf import rna2pro
mrnafile=input("Enter a file.fna path or a mRNA sequence : ").strip().strip("'")
if mrnafile[:8].isalpha() and mrnafile[:-6].isalpha():
    transcripts = {'rna1':mrnafile.upper()}
else:
    with open(f"{mrnafile}","r") as rna:
        rc=0
        transcripts={}
        while True:
            try:
                newline=rna.readline()
                if newline[0].isalpha():
                    transcripts[f'rna{rc}']+=newline.strip().upper()
                else:
                    rc+=1
                    transcripts.update({f'rna{rc}': ""})
            except:
                break

counter=0
savetofile=[]
for mrna in transcripts.keys():
    counter+=1
    print(f"____________transcript {counter} ____________")
    savetofile.append(f"____________transcript {counter} ____________\n")
    sortedorfs=findorfs(transcripts[mrna])
    framecounter=0
    for i in sortedorfs:
        framecounter+=1
        if i[0]==0:
            print(f'Frame {framecounter}: Residues {0},', 'There is no start codon!')
            savetofile.append(f'>Frame {framecounter}, Residues {0}\n:There is no start codon!\n')
        elif i[0]==1:
            print(f'Frame {framecounter}: Residues {"*"},', 'There is no stop codon!')
            savetofile.append(f'>Frame {framecounter}, Residues {"*"}:\nThere is no stop codon!\n')
        else:
            result=''.join(rna2pro(i[1]))
            print(f'Frame {framecounter}: Residues {len(result)},',result)
            savetofile.append(f'>Frame {framecounter}, Residues {len(result)}:\n{result}\n')

asktosave=input("Do you want to save results as a new file? if yes, enter 'y'\n'Y' or 'N' : ")
if asktosave.strip().lower()=="y" or asktosave.strip().lower()=="yes":
    outputdir=input('Enter output directory: ').strip().rstrip('/')
    try:
        if outputdir[0]=="/":
            with open(f'{outputdir}/protein_output.fna', 'w') as output:
                for i in savetofile:
                    output.write(i)
        else:
            with open(f'{outputdir}\protein_output.fna', 'w') as output:
                for i in savetofile:
                    output.write(i)
    except:
        print("ERROR. No such directory!")
    else:
        print("Well done!")
